# Supplementary Material

## The Checkpoint Selection Problem Is an Evaluation Budget Problem

### Contents

- `paper.pdf` — The manuscript
- `source/` — LaTeX source and figures
  - `main.tex`, `refs.bib`, `math_commands.tex`, `tmlr.sty`, `fancyhdr.sty`
  - `figures/` — All 5 figures (PNG) and their generation scripts (.py)
- `code/` — Training and evaluation scripts
  - `train_7b.py` — LoRA fine-tuning (Qwen2.5-7B, 500 steps, multi-task data)
  - `run_1.5b.py` — Supplementary 1.5B experiment
  - `seed_full_eval.py` — Full 10-point evaluation for seed replication
  - `seed44_only.py`, `seed_replication.py` — Seed replication scripts
  - `mcnemar.py`, `mcnemar2.py` — McNemar paired test analysis
  - `mmlu_eval.py` — MMLU evaluation
  - `eval_7b_fixed.py` — GSM8K few-shot evaluation
- `results/` — Key experimental results (JSON)
  - `seed_full_eval_results.json` — Full 10-point trajectories for seeds 43, 44
  - `seed42_training_format.json` — Seed 42 training-format accuracies
  - `mcnemar_results.json` — Per-sample correctness for McNemar analysis

### Requirements

- Python 3.10+, PyTorch, Transformers, PEFT, TRL, Datasets, SciPy
- See `paas_code/requirements.txt` in the full codebase (will be released upon publication)

### Reproducing Results

1. Run `train_7b.py` to fine-tune Qwen2.5-7B with LoRA
2. Run `seed_full_eval.py` to evaluate all checkpoints
3. Run figure scripts in `source/figures/` to regenerate figures

### Anonymity

This supplementary material is anonymized for submission. The full codebase will be released upon publication.
