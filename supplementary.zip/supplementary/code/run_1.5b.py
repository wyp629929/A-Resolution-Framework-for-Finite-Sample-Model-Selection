import os, json, sys, re, glob
os.environ["HF_HOME"] = "/root/autodl-tmp/.hf"
os.environ["HF_DATASETS_OFFLINE"] = "1"
os.makedirs(os.environ["HF_HOME"], exist_ok=True)

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, TrainingArguments
from peft import LoraConfig
from trl import SFTTrainer
from datasets import Dataset

# Config
BASE_MODEL = "/root/autodl-tmp/.hf/modelscope/Qwen/Qwen2.5-1.5B-Instruct"
LORA_RANK = 16
TOTAL_STEPS = 500
SAVE_EVERY = 50
BATCH_SIZE = 4
GRAD_ACCUM = 4
LR = 2e-4
SCHEDULE = "cosine"
SEED = 42
OUTPUT_DIR = "/root/autodl-tmp/paas_1.5b/results/checkpoints"
DATA_DIR = "/root/autodl-tmp/paas_1.5b/data"

print(f"Model: {BASE_MODEL}", flush=True)
print(f"GPU: {torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'none'}", flush=True)

# Load model
print("Loading model...", flush=True)
model = AutoModelForCausalLM.from_pretrained(
    BASE_MODEL, torch_dtype=torch.bfloat16, device_map="auto",
    low_cpu_mem_usage=True,
)
tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL)
tokenizer.pad_token = tokenizer.eos_token
print("Model loaded", flush=True)

peft_config = LoraConfig(
    r=LORA_RANK,
    lora_alpha=LORA_RANK * 2,
    target_modules=["q_proj", "v_proj", "k_proj", "o_proj"],
    lora_dropout=0.1,
    bias="none",
    task_type="CAUSAL_LM",
)

# Load datasets from local JSON
print("Loading datasets...", flush=True)
with open(f"{DATA_DIR}/gsm8k_train.json") as f:
    gsm8k = json.load(f)
with open(f"{DATA_DIR}/codealpaca_train.json") as f:
    codealpaca = json.load(f)
with open(f"{DATA_DIR}/dolly_sample.json") as f:
    dolly = json.load(f)

texts = []
for s in gsm8k:
    texts.append(f"Question: {s['question']}\nAnswer: {s['answer']}")
for s in codealpaca:
    texts.append(f"Instruction: {s['instruction']}\nOutput: {s['output']}")
for s in dolly:
    texts.append(f"Instruction: {s.get('instruction','')}\nResponse: {s.get('response','')}")

dataset = Dataset.from_dict({"text": texts}).shuffle(seed=42)
print(f"Training samples: {len(dataset)}", flush=True)

# Training
training_args = TrainingArguments(
    output_dir=OUTPUT_DIR,
    per_device_train_batch_size=BATCH_SIZE,
    gradient_accumulation_steps=GRAD_ACCUM,
    learning_rate=LR,
    max_steps=TOTAL_STEPS,
    save_steps=SAVE_EVERY,
    save_total_limit=None,
    logging_steps=10,
    lr_scheduler_type=SCHEDULE,
    seed=SEED,
    bf16=True,
    report_to="none",
    run_name=f"paas_1.5b_seed{SEED}",
    dataloader_num_workers=0,
    ddp_find_unused_parameters=False,
)

trainer = SFTTrainer(
    model=model,
    tokenizer=tokenizer,
    args=training_args,
    peft_config=peft_config,
    train_dataset=dataset,
    dataset_text_field="text",
    max_seq_length=512,
)

print("Starting training...", flush=True)
trainer.train()
print("Training complete.", flush=True)

# Collect checkpoints
ckpt_dirs = sorted(
    glob.glob(os.path.join(OUTPUT_DIR, "checkpoint-*")),
    key=lambda p: int(p.split("-")[-1]),
)
print(f"Checkpoints: {len(ckpt_dirs)}", flush=True)

# GSM8K evaluation
def extract_answer(text):
    match = re.search(r"####\s*([\d.,]+)", text)
    if match:
        return match.group(1).replace(",", "")
    numbers = re.findall(r"[-+]?\d+(?:\.\d+)?", text)
    return numbers[-1] if numbers else None

with open(f"{DATA_DIR}/gsm8k_test.json") as f:
    gsm8k_test = json.load(f)
print(f"GSM8K test samples: {len(gsm8k_test)}", flush=True)

from peft import PeftModel

results = []
for ckpt_path in ckpt_dirs:
    step = int(ckpt_path.split("-")[-1])
    print(f"\nEvaluating step {step}...", flush=True)

    base = AutoModelForCausalLM.from_pretrained(
        BASE_MODEL, torch_dtype=torch.bfloat16, device_map="auto",
    )
    try:
        lora_model = PeftModel.from_pretrained(base, ckpt_path)
    except Exception as e:
        print(f"  Failed: {e}", flush=True)
        results.append({"step": step, "accuracy": None, "n": 0, "error": str(e)})
        del base; torch.cuda.empty_cache()
        continue

    lora_model = lora_model.merge_and_unload()
    tok = AutoTokenizer.from_pretrained(BASE_MODEL)
    tok.pad_token = tok.eos_token

    correct = 0
    total = 0
    for sample in gsm8k_test:
        expected = extract_answer(sample.get("answer", ""))
        if expected is None:
            continue
        inputs = tok(sample["question"], return_tensors="pt", truncation=True,
                     max_length=512).to(lora_model.device)
        output = lora_model.generate(**inputs, max_new_tokens=128,
                                      pad_token_id=tok.eos_token_id)
        response = tok.decode(output[0], skip_special_tokens=True)
        predicted = extract_answer(response)
        if predicted is not None and predicted == expected:
            correct += 1
        total += 1

    acc = correct / total if total > 0 else 0
    results.append({"step": step, "accuracy": round(acc, 4), "n": total})
    print(f"  Acc: {acc*100:.1f}% ({correct}/{total})", flush=True)
    del lora_model, base, tok; torch.cuda.empty_cache()

# Save results
out = {
    "experiment": "qwen2.5_1.5b_lora16_cosine_seed42",
    "model": "Qwen/Qwen2.5-1.5B-Instruct",
    "total_steps": TOTAL_STEPS,
    "save_every": SAVE_EVERY,
    "results": results,
}
out_path = f"{DATA_DIR}/../results/gsm8k_results.json"
os.makedirs(os.path.dirname(out_path), exist_ok=True)
with open(out_path, "w") as f:
    json.dump(out, f, indent=2)

print(f"\nSaved: {out_path}", flush=True)
print(json.dumps(out, indent=2), flush=True)
