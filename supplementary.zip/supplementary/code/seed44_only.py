"""Only seed 44 training + eval."""
import os, json, re, torch, time, sys, glob
os.environ['HF_HOME'] = '/root/autodl-tmp/.hf'
from transformers import AutoModelForCausalLM, AutoTokenizer, TrainingArguments
from peft import LoraConfig, PeftModel
from trl import SFTTrainer
from datasets import Dataset

BASE = '/root/autodl-tmp/.hf/modelscope/Qwen/Qwen2.5-7B-Instruct'
DATA_DIR = '/root/autodl-tmp/paas_1.5b/data'
OUT_DIR = '/root/autodl-tmp/paas_1.5b/results'
SEED = 44

def extract(text):
    m = re.search(r'####\s*([\d.,]+)', text)
    return m.group(1).replace(',', '') if m else None

out = f'{OUT_DIR}/seed{SEED}_checkpoints'

with open(f'{DATA_DIR}/gsm8k_train.json') as f: gsm8k = json.load(f)
with open(f'{DATA_DIR}/codealpaca_train.json') as f: code = json.load(f)
with open(f'{DATA_DIR}/dolly_sample.json') as f: dolly = json.load(f)
texts = []
for s in gsm8k: texts.append(f"Question: {s['question']}\nAnswer: {s['answer']}")
for s in code: texts.append(f"Instruction: {s['instruction']}\nOutput: {s['output']}")
for s in dolly: texts.append(f"Instruction: {s.get('instruction','')}\nResponse: {s.get('response','')}")
dataset = Dataset.from_dict({'text': texts}).shuffle(seed=SEED)
print(f'Samples: {len(dataset)}', flush=True)

model = AutoModelForCausalLM.from_pretrained(BASE, torch_dtype=torch.bfloat16, device_map='cuda:0')
tok = AutoTokenizer.from_pretrained(BASE); tok.pad_token = tok.eos_token
peft = LoraConfig(r=16, lora_alpha=32, target_modules=['q_proj','v_proj','k_proj','o_proj'], lora_dropout=0.1, bias='none', task_type='CAUSAL_LM')
args = TrainingArguments(output_dir=out, per_device_train_batch_size=2, gradient_accumulation_steps=4, learning_rate=2e-4, max_steps=500, save_steps=50, save_total_limit=None, logging_steps=10, lr_scheduler_type='cosine', seed=SEED, bf16=True, report_to='none', run_name=f'paas_seed{SEED}', dataloader_num_workers=0)
trainer = SFTTrainer(model=model, tokenizer=tok, args=args, peft_config=peft, train_dataset=dataset, dataset_text_field='text', max_seq_length=512)
print('Training...', flush=True)
trainer.train()
print('Training done', flush=True)

del model, trainer; torch.cuda.empty_cache(); torch.cuda.synchronize()

ckpts = sorted(glob.glob(out + '/checkpoint-*'), key=lambda p: int(p.split('-')[-1]))
results = {}
for cp in ckpts:
    step = int(cp.split('-')[-1])
    if step not in [50, 150, 500]: continue
    print(f'\nEval step {step}...', flush=True)
    base = AutoModelForCausalLM.from_pretrained(BASE, torch_dtype=torch.bfloat16, device_map='cuda:0')
    m = PeftModel.from_pretrained(base, cp)
    m = m.merge_and_unload()
    with open(f'{DATA_DIR}/gsm8k_test.json') as f:
        test = json.load(f)[:200]
    correct = total = 0; t0 = time.time()
    for s in test:
        exp = extract(s.get('answer', ''))
        if not exp: continue
        prompt = 'Question: ' + s['question'] + '\nAnswer:'
        inp = tok(prompt, return_tensors='pt', truncation=True, max_length=512).to(m.device)
        out = m.generate(**inp, max_new_tokens=128, pad_token_id=tok.eos_token_id, do_sample=False)
        resp = tok.decode(out[0], skip_special_tokens=True)
        pred = extract(resp)
        if pred == exp: correct += 1
        total += 1
    acc = correct / total
    results[step] = round(acc, 4)
    print(f'  = {acc*100:.1f}% [{time.time()-t0:.0f}s]', flush=True)
    del m, base; torch.cuda.empty_cache(); torch.cuda.synchronize()

print(f'\nSeed {SEED} results:', flush=True)
for s, r in results.items():
    print(f'  Step {s}: {r*100:.1f}%', flush=True)

with open(f'{OUT_DIR}/seed{SEED}_results.json', 'w') as f:
    json.dump(results, f, indent=2)
print('Done!', flush=True)
