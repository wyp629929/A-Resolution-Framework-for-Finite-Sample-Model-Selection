"""McNemar paired test with training-format prompt."""
import os, json, re, torch, time, glob
os.environ['HF_HOME'] = '/root/autodl-tmp/.hf'
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel
from scipy.stats import chi2

BASE = '/root/autodl-tmp/.hf/modelscope/Qwen/Qwen2.5-7B-Instruct'
CKPT = '/root/autodl-tmp/paas_1.5b/results/7b_checkpoints'
DATA = '/root/autodl-tmp/paas_1.5b/data'

def extract(text):
    m = re.search(r'####\s*([\d.,]+)', text)
    return m.group(1).replace(',', '') if m else None

with open(f'{DATA}/gsm8k_test.json') as f:
    all_data = json.load(f)[:200]

tok = AutoTokenizer.from_pretrained(BASE)
tok.pad_token = tok.eos_token

dirs = sorted(glob.glob(f'{CKPT}/checkpoint-*'), key=lambda p: int(p.split('-')[-1]))
print(f'Checkpoints: {len(dirs)}', flush=True)

per_sample = {}
for cp in dirs:
    step = int(cp.split('-')[-1])
    print(f'\n--- Step {step} ---', flush=True)
    base = AutoModelForCausalLM.from_pretrained(BASE, torch_dtype=torch.bfloat16, device_map='auto')
    m = PeftModel.from_pretrained(base, cp)
    m = m.merge_and_unload()
    results = []
    t0 = time.time()
    for s in all_data:
        exp = extract(s.get('answer', ''))
        if not exp: results.append(0); continue
        prompt = 'Question: ' + s['question'] + '\nAnswer:'
        inp = tok(prompt, return_tensors='pt', truncation=True, max_length=512).to(m.device)
        out = m.generate(**inp, max_new_tokens=128, pad_token_id=tok.eos_token_id, do_sample=False)
        resp = tok.decode(out[0], skip_special_tokens=True)
        pred = extract(resp)
        results.append(1 if pred == exp else 0)
    acc = sum(results) / len(results)
    per_sample[str(step)] = results
    print(f'  Acc: {acc*100:.1f}% ({sum(results)}/{len(results)}) [{time.time()-t0:.0f}s]', flush=True)
    del m, base; torch.cuda.empty_cache(); torch.cuda.synchronize()

print('\n=== McNemar Tests ===', flush=True)
steps_sorted = sorted(per_sample.keys(), key=int)
mcnemar_results = []
for i in range(len(steps_sorted) - 1):
    s1, s2 = steps_sorted[i], steps_sorted[i+1]
    a, b = per_sample[s1], per_sample[s2]
    n01 = sum(1 for x, y in zip(a, b) if x == 0 and y == 1)
    n10 = sum(1 for x, y in zip(a, b) if x == 1 and y == 0)
    n = n01 + n10
    p_val = 1.0 if n == 0 else 1 - chi2.cdf((abs(n01 - n10) - 1) ** 2 / n, 1)
    mcnemar_results.append({'pair': f'{s1}->{s2}', 'n01': n01, 'n10': n10, 'p': round(p_val, 4)})
    print(f'  {s1}->{s2}: discordant=({n01},{n10}) p={p_val:.4f}', flush=True)

best = max(per_sample, key=lambda s: sum(per_sample[s]))
worst = min(per_sample, key=lambda s: sum(per_sample[s]))
a, b = per_sample[best], per_sample[worst]
n01 = sum(1 for x, y in zip(a, b) if x == 0 and y == 1)
n10 = sum(1 for x, y in zip(a, b) if x == 1 and y == 0)
n = n01 + n10
p_val = 1.0 if n == 0 else 1 - chi2.cdf((abs(n01 - n10) - 1) ** 2 / n, 1)
mcnemar_results.append({'pair': f'best({best})_vs_worst({worst})', 'n01': n01, 'n10': n10, 'p': round(p_val, 4)})
print(f'  best({best})_vs_worst({worst}): discordant=({n01},{n10}) p={p_val:.4f}', flush=True)

accs = {s: round(sum(v)/len(v), 4) for s, v in per_sample.items()}
out = {'per_sample': per_sample, 'accuracies': accs, 'mcnemar': mcnemar_results}
with open('/root/autodl-tmp/paas_1.5b/results/mcnemar_results.json', 'w') as f:
    json.dump(out, f, indent=2)
print('Saved!', flush=True)
