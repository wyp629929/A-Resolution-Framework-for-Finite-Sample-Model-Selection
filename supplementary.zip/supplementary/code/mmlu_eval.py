import os, json, re, torch, time, glob, sys
os.environ['HF_HOME'] = '/root/autodl-tmp/.hf'
os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'
from datasets import load_dataset
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel
from scipy.stats import spearmanr

BASE = '/root/autodl-tmp/.hf/modelscope/Qwen/Qwen2.5-7B-Instruct'
CKPT = '/root/autodl-tmp/paas_1.5b/results/7b_checkpoints'
SUBJECTS = ['abstract_algebra', 'anatomy', 'college_computer_science', 'world_religions', 'jurisprudence']
MAX_PER = 50

all_data = []
for subj in SUBJECTS:
    ds = load_dataset('hails/mmlu_no_train', subj, split='test')
    for i in range(min(MAX_PER, len(ds))):
        row = ds[i]
        opts = chr(65) + '. ' + row['choices'][0] + chr(10) + chr(65+1) + '. ' + row['choices'][1] + chr(10) + chr(65+2) + '. ' + row['choices'][2] + chr(10) + chr(65+3) + '. ' + row['choices'][3]
        prompt = 'Question: ' + row['question'] + chr(10) + opts + chr(10) + 'Answer:'
        all_data.append({'prompt': prompt, 'expected': chr(65 + row['answer'])})
    print(subj + ': ' + str(min(MAX_PER, len(ds))) + ' samples', flush=True)
print('Total: ' + str(len(all_data)), flush=True)

tok = AutoTokenizer.from_pretrained(BASE)
tok.pad_token = tok.eos_token
dirs = sorted(glob.glob(CKPT + '/checkpoint-*'), key=lambda p: int(p.split('-')[-1]))

per_sample = {}
for cp in dirs:
    step = int(cp.split('-')[-1])
    print('', flush=True)
    print('--- Step ' + str(step) + ' ---', flush=True)
    base = AutoModelForCausalLM.from_pretrained(BASE, torch_dtype=torch.bfloat16, device_map='auto')
    m = PeftModel.from_pretrained(base, cp)
    m = m.merge_and_unload()
    results = []
    t0 = time.time()
    for s in all_data:
        inp = tok(s['prompt'], return_tensors='pt', truncation=True, max_length=512).to(m.device)
        out = m.generate(**inp, max_new_tokens=5, pad_token_id=tok.eos_token_id, do_sample=False)
        resp = tok.decode(out[0], skip_special_tokens=True)
        match = re.search(r'[ABCD](?=[^ABCD]*$)', resp) or re.search(r'[ABCD]', resp)
        pred = match.group(0) if match else ''
        results.append(1 if pred == s['expected'] else 0)
    acc = sum(results) / len(results) if results else 0
    per_sample[str(step)] = results
    print('  Acc: ' + str(round(acc*100, 1)) + '% (' + str(sum(results)) + '/' + str(len(results)) + ') [' + str(int(time.time()-t0)) + 's]', flush=True)
    del m, base; torch.cuda.empty_cache(); torch.cuda.synchronize()

steps_sorted = sorted(per_sample.keys(), key=int)
accs = {s: sum(v)/len(v) for s, v in per_sample.items()}
print('', flush=True)
print('=== MMLU Trajectory ===', flush=True)
for s in steps_sorted:
    print('  Step ' + s + ': ' + str(round(accs[s]*100, 1)) + '%', flush=True)

steps_int = [int(s) for s in steps_sorted]
acc_vals = [accs[s] for s in steps_sorted]
rho, p_trend = spearmanr(steps_int, acc_vals)
print('Trend: rho=' + str(round(rho,3)) + ' p=' + str(round(p_trend,4)), flush=True)

best_s = max(per_sample, key=lambda s: sum(per_sample[s]))
worst_s = min(per_sample, key=lambda s: sum(per_sample[s]))
rng = (accs[best_s]-accs[worst_s])*100
print('Best: step ' + best_s + ' (' + str(round(accs[best_s]*100,1)) + '%), Worst: step ' + worst_s + ' (' + str(round(accs[worst_s]*100,1)) + '%)', flush=True)
print('Range: ' + str(round(rng,1)) + ' pp', flush=True)

p_bar = sum(acc_vals) / len(acc_vals)
delta_min = 1.96 * (2 * p_bar * (1 - p_bar) / len(all_data)) ** 0.5 * 100
print('Mean=' + str(round(p_bar,3)) + ' Delta_min=' + str(round(delta_min,1)) + ' pp', flush=True)

out = {'per_sample': per_sample, 'accuracies': accs, 'trend': {'rho': round(rho,3), 'p': round(p_trend,4)}, 'range_pp': round(rng,1), 'delta_min_pp': round(delta_min,1)}
with open('results/mmlu_results.json', 'w') as f:
    json.dump(out, f, indent=2)
print('Done!', flush=True)
