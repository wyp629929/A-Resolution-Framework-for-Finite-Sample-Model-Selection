"""
Evaluate ALL 10 checkpoints for seeds 43, 44 on GSM8K (N=200, training-format prompt).

Addresses reviewer concern (§3.8): original seed replication used only 3 of 10
checkpoints per seed, making the 3-point range mechanically smaller than the
main experiment's 10-point range.

Output per seed:
  - Full 10-point GSM8K trajectory
  - Spearman trend (n=10, with p-value)
  - 9 adjacent two-proportion z-tests (cf. Table 2)
  - Best-vs-worst test
  - Actual p̄ and corresponding Δ_min
  - Comparison: observed range vs Δ_min

Protocol matches existing seed44_results.json (training-format prompt,
Question: ...\nAnswer:, #### extraction).
"""
import os, json, re, torch, time, math
os.environ['HF_HOME'] = '/root/autodl-tmp/.hf'
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel
from scipy.stats import norm, spearmanr

# Verified against seed44_only.py L58, seed_replication.py L65
MAX_NEW_TOKENS = 128

BASE = '/root/autodl-tmp/.hf/modelscope/Qwen/Qwen2.5-7B-Instruct'
DATA_DIR = '/root/autodl-tmp/paas_1.5b/data'
RESULTS_DIR = '/root/autodl-tmp/paas_1.5b/results'
SEEDS = [43, 44]
STEPS = [50, 100, 150, 200, 250, 300, 350, 400, 450, 500]
Z_ALPHA = norm.ppf(0.975)  # α=0.05 two-tailed

def extract(text):
    m = re.search(r'####\s*([\d.,]+)', text)
    return m.group(1).replace(',', '') if m else None

def answers_match(pred, exp):
    """Fuzzy numeric comparison with string fallback — handles "72.0" vs "72"."""
    if pred is None or exp is None:
        return pred == exp
    try:
        return float(pred) == float(exp)
    except ValueError:
        return pred == exp

def two_prop_z_test(acc1, n1, acc2, n2):
    """Independent two-proportion z-test, matching main experiment."""
    p_pool = (acc1 * n1 + acc2 * n2) / (n1 + n2)
    se = math.sqrt(p_pool * (1 - p_pool) * (1/n1 + 1/n2))
    z = (acc1 - acc2) / se if se > 0 else 0.0
    p = 2 * (1 - norm.cdf(abs(z)))  # two-tailed
    return round(z, 4), round(p, 4)

def compute_delta_min(p_bar, n):
    """Δ_min = z_α/2 · √(2p̄(1-p̄)/N)"""
    return round(Z_ALPHA * math.sqrt(2 * p_bar * (1 - p_bar) / n), 4)

def format_pct(v):
    """Format a proportion as percentage string."""
    return f"{v*100:.1f}%"

# Load test data — match original protocol: first 200 entries with extractable answers
with open(f'{DATA_DIR}/gsm8k_test.json') as f:
    test = json.load(f)

valid_indices = [(i, s) for i, s in enumerate(test) if extract(s.get('answer', ''))]
valid_indices = valid_indices[:200]
N = len(valid_indices)
assert N == 200, f"Expected N=200, got {N}"
print(f'GSM8K test: {len(test)} total, {N} valid samples', flush=True)

# Load tokenizer once
tok = AutoTokenizer.from_pretrained(BASE)
tok.pad_token = tok.eos_token

all_results = {}  # {seed_str: {step: acc}}

for seed in SEEDS:
    print(f'\n{"="*70}', flush=True)
    print(f'Seed {seed}', flush=True)
    print(f'{"="*70}', flush=True)

    ckpt_dir = f'{RESULTS_DIR}/seed{seed}_checkpoints'
    results = {}
    per_seed_path = f'{RESULTS_DIR}/seed{seed}_full_eval_progress.json'

    # Resume from existing progress if available
    if os.path.exists(per_seed_path):
        with open(per_seed_path) as f:
            results = json.load(f)
            results = {int(k): v for k, v in results.items()}
        print(f'Resuming: {len(results)} checkpoints already evaluated', flush=True)

    for step in STEPS:
        step_str = str(step)
        if step in results:
            print(f'Step {step}: {format_pct(results[step])} (cached)', flush=True)
            continue

        ckpt_path = f'{ckpt_dir}/checkpoint-{step}'
        if not os.path.isdir(ckpt_path):
            print(f'  Step {step}: checkpoint not found, skipping', flush=True)
            continue

        print(f'\nStep {step}...', flush=True)
        t0 = time.time()

        # Fresh model each iteration — safest against state pollution
        base = AutoModelForCausalLM.from_pretrained(
            BASE,
            torch_dtype=torch.bfloat16,
            device_map='cuda:0'
        )
        model = PeftModel.from_pretrained(base, ckpt_path)
        model = model.merge_and_unload()
        model.eval()

        correct = 0
        for _, s in valid_indices:
            exp = extract(s['answer'])
            prompt = 'Question: ' + s['question'] + '\nAnswer:'
            inp = tok(prompt, return_tensors='pt', truncation=True, max_length=512).to('cuda:0')

            with torch.no_grad():
                out = model.generate(
                    **inp,
                    max_new_tokens=MAX_NEW_TOKENS,
                    pad_token_id=tok.eos_token_id,
                    do_sample=False  # greedy — no generation stochasticity
                )

            resp = tok.decode(out[0], skip_special_tokens=True)
            pred = extract(resp)
            if answers_match(pred, exp):
                correct += 1

        acc = round(correct / len(valid_indices), 4)
        results[step] = acc
        elapsed = time.time() - t0
        print(f'  = {format_pct(acc)} [{elapsed:.0f}s]', flush=True)

        # Free memory before next iteration
        del model, base
        torch.cuda.empty_cache()
        torch.cuda.synchronize()

        # Incremental save
        with open(per_seed_path, 'w') as f:
            json.dump({str(k): v for k, v in results.items()}, f, indent=2)

    # ── Full statistical report for this seed ──
    ordered = sorted(results.keys())
    vals = [results[s] for s in ordered]
    p_bar = sum(vals) / len(vals)
    if len(ordered) < len(STEPS):
        print(f'⚠️  WARNING: only {len(ordered)}/{len(STEPS)} checkpoints found — stats below on reduced sample', flush=True)

    d_min = compute_delta_min(p_bar, n=N)

    print(f'\n{"─"*70}', flush=True)
    print(f'Seed {seed} — Full statistical report', flush=True)
    print(f'{"─"*70}', flush=True)
    print(f'Trajectory: {", ".join(f"step {s}: {format_pct(results[s])}" for s in ordered)}', flush=True)
    print(f'Mean accuracy p̄ = {format_pct(p_bar)}', flush=True)
    print(f'Δ_min (N={N}, p̄={format_pct(p_bar)}) = {d_min*100:.1f} pp', flush=True)

    # Spearman trend
    rho, p_rho = spearmanr(ordered, vals)
    print(f'Spearman trend: ρ = {rho:.3f} (p = {p_rho:.4f})', flush=True)

    # Adjacent pair z-tests
    print(f'\nAdjacent comparisons:', flush=True)
    all_ps = []
    for i in range(len(ordered) - 1):
        s1, s2 = ordered[i], ordered[i+1]
        z, p = two_prop_z_test(results[s1], N, results[s2], N)
        delta = (results[s2] - results[s1]) * 100
        all_ps.append(p)
        sig = " *" if p < 0.05 else ""
        print(f'  {s1}→{s2}: Δ={delta:+.1f}pp, z={z:.3f}, p={p:.4f}{sig}', flush=True)

    print(f'  Min p across adjacent pairs: {min(all_ps):.4f}', flush=True)
    print(f'  Any significant at α=0.05? {"Yes" if any(p < 0.05 for p in all_ps) else "No"}', flush=True)

    # Best-vs-worst
    best_step = max(results, key=results.get)
    worst_step = min(results, key=results.get)
    z_bw, p_bw = two_prop_z_test(results[best_step], N, results[worst_step], N)
    bw_range = (results[best_step] - results[worst_step]) * 100
    print(f'\nBest-vs-worst:', flush=True)
    print(f'  Best: step {best_step} ({format_pct(results[best_step])})', flush=True)
    print(f'  Worst: step {worst_step} ({format_pct(results[worst_step])})', flush=True)
    print(f'  Range: {bw_range:.1f} pp', flush=True)
    print(f'  z = {z_bw:.3f}, p = {p_bw:.4f}', flush=True)
    print(f'  Δ_min = {d_min*100:.1f} pp', flush=True)
    print(f'  Range < Δ_min? {"Yes" if bw_range < d_min*100 else "No"}', flush=True)

# ── Cross-seed summary ──
print(f'\n{"="*70}', flush=True)
print(f'Cross-seed summary', flush=True)
print(f'{"="*70}', flush=True)
for s in SEEDS:
    with open(f'{RESULTS_DIR}/seed{s}_full_eval_progress.json') as f:
        r = {int(k): v for k, v in json.load(f).items()}
    ordered = sorted(r.keys())
    vals = [r[st] for st in ordered]
    p_bar = sum(vals) / len(vals)
    d_min = compute_delta_min(p_bar, n=N)
    rng = (max(vals) - min(vals)) * 100
    rho, p_rho = spearmanr(ordered, vals)
    print(f'Seed {s}: range={rng:.1f}pp, Δ_min(N={N})={d_min*100:.1f}pp, ρ={rho:.3f} (p={p_rho:.4f})', flush=True)

# Final consolidated save
all_final = {}
for s in SEEDS:
    with open(f'{RESULTS_DIR}/seed{s}_full_eval_progress.json') as f:
        all_final[str(s)] = {int(k): v for k, v in json.load(f).items()}

output_path = f'{RESULTS_DIR}/seed_full_eval_results.json'
with open(output_path, 'w') as f:
    json.dump(all_final, f, indent=2)
print(f'\nConsolidated results saved to {output_path}', flush=True)
print('Done!', flush=True)
