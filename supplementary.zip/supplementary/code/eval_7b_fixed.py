"""7B model soup: plain text format (matching training format)."""
import os, json, re, torch, time, glob, sys
os.environ['HF_HOME'] = '/root/autodl-tmp/.hf'
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel

BASE = '/root/autodl-tmp/.hf/modelscope/Qwen/Qwen2.5-7B-Instruct'
CKPT = '/root/autodl-tmp/paas_1.5b/results/7b_checkpoints'
DATA = '/root/autodl-tmp/paas_1.5b/data'

def extract(text):
    m = re.search(r'####\s*([\d.,]+)', text)
    return m.group(1).replace(',', '') if m else None

with open(f'{DATA}/gsm8k_test.json') as f:
    all_data = json.load(f)[:200]

tok = AutoTokenizer.from_pretrained(BASE)
tok.pad_token = tok.eos_token

def evaluate(adapter_path, label):
    print(f'\n== {label} ==', flush=True)
    base = AutoModelForCausalLM.from_pretrained(BASE, torch_dtype=torch.bfloat16, device_map='auto')
    m = PeftModel.from_pretrained(base, adapter_path)
    m = m.merge_and_unload()
    correct = total = 0
    t0 = time.time()
    for s in all_data:
        exp = extract(s.get('answer', ''))
        if not exp: continue
        prompt = 'Question: ' + s['question'] + '\nAnswer:'
        inp = tok(prompt, return_tensors='pt', truncation=True, max_length=512).to(m.device)
        out = m.generate(**inp, max_new_tokens=128, pad_token_id=tok.eos_token_id, do_sample=False)
        resp = tok.decode(out[0], skip_special_tokens=True)
        pred = extract(resp)
        if pred == exp: correct += 1
        total += 1
    acc = correct / total
    print(f'  {label}: {acc*100:.1f}% ({correct}/{total}) [{time.time()-t0:.0f}s]', flush=True)
    del m, base; torch.cuda.empty_cache(); torch.cuda.synchronize()
    return acc

a1 = evaluate(f'{CKPT}/checkpoint-150', 'Argmax(step150)')

# Model soup
print('\n== Building Soup ==', flush=True)
dirs = sorted(glob.glob(f'{CKPT}/checkpoint-*'), key=lambda p: int(p.split('-')[-1]))
base = AutoModelForCausalLM.from_pretrained(BASE, torch_dtype=torch.bfloat16, device_map='auto')
first = PeftModel.from_pretrained(base, dirs[0])
adapter_keys = [k for k in first.state_dict().keys() if 'lora' in k.lower()]
t0 = time.time()
avg_sd = {k: first.state_dict()[k].float().cpu() for k in adapter_keys}
for cp in dirs[1:]:
    m = PeftModel.from_pretrained(base, cp)
    for k in adapter_keys:
        avg_sd[k] += m.state_dict()[k].float().cpu()
    del m; torch.cuda.empty_cache()
for k in adapter_keys: avg_sd[k] /= len(dirs)
first.load_state_dict(avg_sd, strict=False)
first = first.merge_and_unload()
print(f'Soup built [{time.time()-t0:.0f}s]', flush=True)
del base; torch.cuda.empty_cache()

# Evaluate soup
print('\n== Evaluating Soup ==', flush=True)
correct = total = 0
t0 = time.time()
for s in all_data:
    exp = extract(s.get('answer', ''))
    if not exp: continue
    prompt = 'Question: ' + s['question'] + '\nAnswer:'
    inp = tok(prompt, return_tensors='pt', truncation=True, max_length=512).to(first.device)
    out = first.generate(**inp, max_new_tokens=128, pad_token_id=tok.eos_token_id, do_sample=False)
    resp = tok.decode(out[0], skip_special_tokens=True)
    pred = extract(resp)
    if pred == exp: correct += 1
    total += 1
a2 = correct / total
print(f'  Soup: {a2*100:.1f}% ({correct}/{total}) [{time.time()-t0:.0f}s]', flush=True)

print(f'\n=== Results ===')
print(f'Argmax(step150): {a1*100:.1f}%')
print(f'Soup(all10):     {a2*100:.1f}%')
print(f'Diff: {a2*100-a1*100:+.1f}pp')
w = 'Argmax' if a1 > a2 else 'Soup' if a2 > a1 else 'Tie'
print(f'Winner: {w}')
