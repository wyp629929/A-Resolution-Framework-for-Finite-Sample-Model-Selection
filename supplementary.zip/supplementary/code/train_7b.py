import os, json, sys, torch, glob, re, time
os.environ['HF_HOME'] = '/root/autodl-tmp/.hf'
from transformers import AutoModelForCausalLM, AutoTokenizer, TrainingArguments
from peft import LoraConfig
from trl import SFTTrainer
from datasets import Dataset

BASE = '/root/autodl-tmp/.hf/modelscope/Qwen/Qwen2.5-7B-Instruct'
DATA_DIR = '/root/autodl-tmp/paas_1.5b/data'
OUTPUT_DIR = '/root/autodl-tmp/paas_1.5b/results/7b_checkpoints'
RANK = 16
STEPS = 500
SAVE_EVERY = 50
BATCH = 2
GRAD_ACCUM = 4
LR = 2e-4

print(f'Model: 7B', flush=True)
print(f'GPU: {torch.cuda.get_device_name(0)}', flush=True)

# Load data from local JSONs
print('Loading data...', flush=True)
with open(f'{DATA_DIR}/gsm8k_train.json') as f: gsm8k = json.load(f)
with open(f'{DATA_DIR}/codealpaca_train.json') as f: code = json.load(f)
with open(f'{DATA_DIR}/dolly_sample.json') as f: dolly = json.load(f)

texts = []
for s in gsm8k: texts.append(f"Question: {s['question']}\nAnswer: {s['answer']}")
for s in code: texts.append(f"Instruction: {s['instruction']}\nOutput: {s['output']}")
for s in dolly: texts.append(f"Instruction: {s.get('instruction','')}\nResponse: {s.get('response','')}")
dataset = Dataset.from_dict({"text": texts}).shuffle(seed=42)
print(f'Samples: {len(dataset)}', flush=True)

# Load model
print('Loading 7B model...', flush=True)
model = AutoModelForCausalLM.from_pretrained(BASE, torch_dtype=torch.bfloat16, device_map='auto')
tokenizer = AutoTokenizer.from_pretrained(BASE)
tokenizer.pad_token = tokenizer.eos_token
print('Model loaded', flush=True)

peft = LoraConfig(r=RANK, lora_alpha=RANK*2,
    target_modules=['q_proj','v_proj','k_proj','o_proj'],
    lora_dropout=0.1, bias='none', task_type='CAUSAL_LM')

args = TrainingArguments(
    output_dir=OUTPUT_DIR,
    per_device_train_batch_size=BATCH,
    gradient_accumulation_steps=GRAD_ACCUM,
    learning_rate=LR,
    max_steps=STEPS,
    save_steps=SAVE_EVERY,
    save_total_limit=None,
    logging_steps=10,
    lr_scheduler_type='cosine',
    seed=42,
    bf16=True,
    report_to='none',
    run_name='paas_7b',
    dataloader_num_workers=0,
    ddp_find_unused_parameters=False,
)

trainer = SFTTrainer(
    model=model, tokenizer=tokenizer, args=args,
    peft_config=peft, train_dataset=dataset,
    dataset_text_field='text', max_seq_length=512,
)

print('Training...', flush=True)
trainer.train()
print('Done training', flush=True)
