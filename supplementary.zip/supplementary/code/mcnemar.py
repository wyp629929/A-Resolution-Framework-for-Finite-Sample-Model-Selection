"""McNemar paired test: evaluate all 7B checkpoints with few-shot, save per-sample."""
import os, json, re, torch, time, glob, sys
os.environ['HF_HOME'] = '/root/autodl-tmp/.hf'
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel
from scipy.stats import chi2

BASE = '/root/autodl-tmp/.hf/modelscope/Qwen/Qwen2.5-7B-Instruct'
CKPT = '/root/autodl-tmp/paas_1.5b/results/7b_checkpoints'
DATA = '/root/autodl-tmp/paas_1.5b/data'
OUT = '/root/autodl-tmp/paas_1.5b/results/mcnemar_results.json'

def extract(text):
    m = re.search(r'####\s*([\d.,]+)', text)
    return m.group(1).replace(',', '') if m else None

# Few-shot prefix (from Trap 6)
fewshot = ("Question: Janet's ducks lay 16 eggs per day. She eats three for breakfast every day "
           "and bakes muffins that use 2 eggs each every day. She has 8 eggs left. "
           "How many days has she been eating and baking?\n"
           "Answer: #### 4\n\n"
           "Question: A robe takes 2 bolts of blue fiber and half that much white fiber. "
           "How many bolts in total does it take?\n"
           "Answer: #### 3\n\n"
           "Question: Josh decides to try flipping a house. He buys a house for $80,000 "
           "and then puts in $50,000 in repairs. This increased the value of the house by 150%. "
           "How much profit did he make?\n"
           "Answer: #### 50000\n\n")

# Load test set
with open(f'{DATA}/gsm8k_test.json') as f:
    all_data = json.load(f)[:200]

# Store per-sample correctness: {step: [0/1, ...]}
per_sample = {}

# Get checkpoint dirs
dirs = sorted(glob.glob(f'{CKPT}/checkpoint-*'), key=lambda p: int(p.split('-')[-1]))
print(f'Checkpoints: {len(dirs)}', flush=True)

tok = AutoTokenizer.from_pretrained(BASE)
tok.pad_token = tok.eos_token

for cp in dirs:
    step = int(cp.split('-')[-1])
    print(f'\n--- Step {step} ---', flush=True)

    base = AutoModelForCausalLM.from_pretrained(BASE, torch_dtype=torch.bfloat16, device_map='auto')
    m = PeftModel.from_pretrained(base, cp)
    m = m.merge_and_unload()

    results = []
    t0 = time.time()
    for s in all_data:
        exp = extract(s.get('answer', ''))
        if not exp:
            results.append(0)
            continue
        prompt = fewshot + f"Question: {s['question']}\nAnswer:"
        inp = tok(prompt, return_tensors='pt', truncation=True, max_length=512).to(m.device)
        out = m.generate(**inp, max_new_tokens=128, pad_token_id=tok.eos_token_id, do_sample=False)
        resp = tok.decode(out[0], skip_special_tokens=True)
        pred = extract(resp)
        results.append(1 if pred == exp else 0)

    acc = sum(results) / len(results)
    per_sample[str(step)] = results
    print(f'  Acc: {acc*100:.1f}% ({sum(results)}/{len(results)}) [{time.time()-t0:.0f}s]', flush=True)
    del m, base; torch.cuda.empty_cache(); torch.cuda.synchronize()

# ---- McNemar Tests ----
print('\n=== McNemar Tests ===', flush=True)

def mcnemar(arr_a, arr_b, label):
    n01 = sum(1 for a, b in zip(arr_a, arr_b) if a == 0 and b == 1)
    n10 = sum(1 for a, b in zip(arr_a, arr_b) if a == 1 and b == 0)
    n = n01 + n10
    if n == 0:
        return {'pair': label, 'n01': 0, 'n10': 0, 'chi2': 0, 'p': 1.0, 'note': 'identical'}
    chi = (abs(n01 - n10) - 1) ** 2 / n  # continuity correction
    p = 1 - chi2.cdf(chi, 1)
    return {'pair': label, 'n01': int(n01), 'n10': int(n10), 'chi2': round(chi, 3), 'p': round(p, 4)}

steps_sorted = sorted(per_sample.keys(), key=int)
mcnemar_results = []
for i in range(len(steps_sorted) - 1):
    s1, s2 = steps_sorted[i], steps_sorted[i+1]
    mcnemar_results.append(mcnemar(per_sample[s1], per_sample[s2], f'{s1}->{s2}'))

# Best vs worst
best_step = max(per_sample, key=lambda s: sum(per_sample[s]))
worst_step = min(per_sample, key=lambda s: sum(per_sample[s]))
mcnemar_results.append(mcnemar(per_sample[best_step], per_sample[worst_step],
                                f'best({best_step})_vs_worst({worst_step})'))

for r in mcnemar_results:
    print(f'  {r["pair"]}: n01={r["n01"]} n10={r["n10"]} chi2={r["chi2"]} p={r["p"]}', flush=True)

# Save
out = {
    'per_sample': per_sample,
    'mcnemar': mcnemar_results,
    'accuracies': {s: round(sum(v)/len(v), 4) for s, v in per_sample.items()},
}
with open(OUT, 'w') as f:
    json.dump(out, f, indent=2)
print(f'\nSaved: {OUT}', flush=True)
